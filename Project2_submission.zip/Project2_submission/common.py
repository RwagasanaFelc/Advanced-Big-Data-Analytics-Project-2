import os
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import psycopg2
from neo4j import GraphDatabase

CAT = timezone(timedelta(hours=2), "CAT")

SETS = {
    "A": dict(account=998,    dest=24755,  day=6),
    "B": dict(account=147228, dest=186823, day=13),
    "C": dict(account=206978, dest=6573,   day=8),
    "D": dict(account=237998, dest=21755,  day=6),
    "E": dict(account=144228, dest=183823, day=13),
    "F": dict(account=203978, dest=3573,   day=8),
}

def hour_bounds(day):
    """09:45:00 inclusive to 10:45:00 exclusive, CAT, September 2026, as epoch seconds."""
    start = datetime(2026, 9, day, 9, 45, 0, tzinfo=CAT)
    end = datetime(2026, 9, day, 10, 45, 0, tzinfo=CAT)
    return int(start.timestamp()), int(end.timestamp())

def norm(v):
    if isinstance(v, Decimal):
        return int(v) if v == v.to_integral_value() else float(v)
    return v

_pg = None
_neo = None

def pg_conn():
    global _pg
    if _pg is None:
        _pg = psycopg2.connect(host="localhost", port=5432, dbname="mobilemoney",
                               user="postgres", password=os.environ.get("PG_PASSWORD", "CHANGE_ME"),
                               options="-c timezone=Africa/Kigali")
        _pg.autocommit = True
    return _pg

def neo_driver():
    global _neo
    if _neo is None:
        _neo = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", os.environ.get("NEO4J_PASSWORD", "CHANGE_ME")))
    return _neo

def run_pg(query, params=None):
    with pg_conn().cursor() as cur:
        cur.execute(query, params or {})
        return [tuple(norm(v) for v in row) for row in cur.fetchall()]

def run_neo(query, params=None):
    with neo_driver().session(database="neo4j") as s:
        return [tuple(norm(v) for v in rec.values()) for rec in s.run(query, params or {})]
