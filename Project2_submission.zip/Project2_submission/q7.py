﻿import json, os, time
from common import SETS, pg_conn, neo_driver

SQL = """WITH RECURSIVE walk(id, depth) AS (
  SELECT a.account_id, 0 FROM accounts a
  WHERE a.account_id = %(account)s AND a.role = 'person'
  UNION
  SELECT t.receiver_id, w.depth + 1
  FROM walk w
  JOIN transfers t ON t.sender_id = w.id
  JOIN accounts r ON r.account_id = t.receiver_id AND r.role = 'person'
  WHERE w.depth < %(bound)s
)
SELECT MIN(depth) FROM walk WHERE id = %(dest)s AND depth > 0"""

# Quantifier bounds must be literals in Cypher, so the integer bound is placed in the text.
CYPHER = """MATCH (a:Account {account_id: $account, role: 'person'}), (b:Account {account_id: $dest, role: 'person'})
MATCH p = SHORTEST 1 (a)(()-[:TRANSFER]->(:Account {role: 'person'})){1,__N__}(b)
RETURN length(p) AS len"""

def pg_len(account, dest, bound):
    with pg_conn().cursor() as cur:
        cur.execute("SET statement_timeout = 170000")
        cur.execute(SQL, dict(account=account, dest=dest, bound=bound))
        return cur.fetchone()[0]

def neo_len(account, dest, bound):
    q = CYPHER.replace("__N__", str(int(bound)))
    with neo_driver().session(database="neo4j") as s:
        rows = list(s.run(q, {"account": account, "dest": dest}, timeout=170))
        return rows[0]["len"] if rows else None

def timed(fn, *a):
    t0 = time.perf_counter()
    try:
        v, st = fn(*a), "ok"
    except Exception as e:
        v, st = None, "error: " + type(e).__name__
    return v, st, time.perf_counter() - t0

path = "results/q7_results.json"
res = json.load(open(path)) if os.path.exists(path) else {}
print("Q7 fewest directed transfers, person accounts only (None = no route within the bound)", flush=True)
print("Set Account  Dest    Bound | SQL len  SQL s | Neo len  Neo s | match", flush=True)
for bound in (4, 6):
    for name, s in SETS.items():
        k = f"{name}-{bound}"
        r = res.get(k)
        if r and r["match"] and r["sql_sec"] < 170 and r["neo_sec"] < 170:
            a, ta, b, tb, ok = r["sql"], r["sql_sec"], r["neo"], r["neo_sec"], True
        else:
            a, sa, ta = timed(pg_len, s["account"], s["dest"], bound)
            b, sb, tb = timed(neo_len, s["account"], s["dest"], bound)
            ok = sa == "ok" and sb == "ok" and a == b
            res[k] = dict(set=name, account=s["account"], dest=s["dest"], bound=bound,
                sql=a, neo=b, sql_status=sa, neo_status=sb, sql_sec=round(ta, 2), neo_sec=round(tb, 2), match=ok)
            json.dump(res, open(path, "w"), indent=1)
            a = a if sa == "ok" else sa
            b = b if sb == "ok" else sb
        print(f"{name:<3} {s['account']:>7} {s['dest']:>7} {bound:>5} | {str(a):>7} {ta:6.1f} | {str(b):>7} {tb:6.1f} | {ok}", flush=True)
print("saved", path)
