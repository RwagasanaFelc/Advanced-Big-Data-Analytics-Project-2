import csv, json, os, time
from itertools import islice
import mobile_money_generator as g

OUT = "data"
os.makedirs(OUT, exist_ok=True)
info = g.dataset_info()
print(json.dumps(info, indent=1))
print("FIELDS:", g.FIELDS)

STREAMS = ["customers", "accounts", "devices", "account_devices", "transfers"]

print("\n--- Preview: first 10 records of each stream ---")
for s in STREAMS:
    print(f"\n{s}:")
    for rec in islice(getattr(g, f"iter_{s}")(), 10):
        print("  ", rec)

audit = {}
for s in STREAMS:
    path = os.path.join(OUT, f"{s}.csv")
    consumed = written = 0
    tmin = tmax = None
    total = 0
    t0 = time.perf_counter()
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=g.FIELDS[s])
        w.writeheader()
        for row in getattr(g, f"iter_{s}")():
            consumed += 1
            w.writerow(row)
            written += 1
            if s == "transfers":
                t, a = row["occurred_at"], row["amount_rwf"]
                tmin = t if tmin is None or t < tmin else tmin
                tmax = t if tmax is None or t > tmax else tmax
                total += a
                if consumed % 1_000_000 == 0:
                    print(f"transfers: {consumed:,} rows", flush=True)
    secs = time.perf_counter() - t0
    expected = info["expected_counts"][s]
    audit[s] = dict(consumed=consumed, written=written, expected=expected,
                    match=(written == expected), seconds=round(secs, 1),
                    csv_bytes=os.path.getsize(path))
    if s == "transfers":
        audit[s].update(transfer_count=consumed, earliest_occurred_at=tmin,
                        latest_occurred_at=tmax, sum_amount_rwf=total)

print("\n--- Capture summary ---")
for s, a in audit.items():
    print(s, a)
with open("capture_audit.json", "w") as f:
    json.dump(audit, f, indent=1)