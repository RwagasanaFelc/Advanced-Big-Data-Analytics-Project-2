# Mobile Money Investigations with PostgreSQL and Neo4j (Project 2)

Group: [Name 1, ID] · [Name 2, ID] · [Name 3, ID]

The same September 2026 mobile money records are loaded into PostgreSQL 16 and Neo4j 5 (Community), the
same seven questions (Q1–Q7) are answered in SQL and Cypher, and both engines are compared for correctness,
single-query speed (Section 6) and concurrent load (Section 7).

## Requirements
- Docker Desktop. Each container is limited to 4 CPUs and 2.5 GB in `docker-compose.yml`.
- Python 3 with `psycopg2-binary`, `neo4j`, `matplotlib`, `numpy`.
- About 10 GB free disk space.

## Secrets (placeholders)
No real passwords are stored in this repository.
1. Copy `.env.example` to `.env` and set `POSTGRES_PASSWORD` and `NEO4J_PASSWORD` (read by Docker Compose).
2. Set the same values for Python in each PowerShell session:
   ```powershell
   $env:PG_PASSWORD = "<your postgres password>"
   $env:NEO4J_PASSWORD = "<your neo4j password>"
   ```

## Execution order (PowerShell, from this folder)

### 0. Start the services (1.1)
```powershell
docker compose up -d
```

### 1. Capture the data (1.2)
```powershell
python capture.py      # streams the unchanged generator into data\*.csv and writes capture_audit.json
```

### 2. Build PostgreSQL (2.1–2.2)
```powershell
foreach ($t in "customers","accounts","devices","account_devices","transfers") { docker cp "data\$t.csv" "mm_postgres:/tmp/$t.csv" }
foreach ($f in "pg_01_schema_load.sql","pg_02_constraints_indexes.sql","pg_03_checks.sql") { docker cp $f "mm_postgres:/tmp/$f" }
docker exec -it mm_postgres psql -a -P pager=off -U postgres -d mobilemoney -f /tmp/pg_01_schema_load.sql          # tables + \copy load (timed)
docker exec -it mm_postgres psql -a -P pager=off -U postgres -d mobilemoney -f /tmp/pg_02_constraints_indexes.sql  # FKs, indexes, BRIN, ANALYZE (timed)
docker exec -it mm_postgres psql -a -P pager=off -U postgres -d mobilemoney -f /tmp/pg_03_checks.sql               # counts, roles, audit totals, sizes
```

### 3. Build Neo4j (3.2)
```powershell
python prepare_import.py                      # typed-header copies in import\ + owns.csv; data\ stays unchanged
docker compose stop neo4j
docker compose run --rm --entrypoint neo4j-admin neo4j database import full neo4j --overwrite-destination --id-type=integer `
  --nodes=Customer=/var/lib/neo4j/import/customers.csv --nodes=Account=/var/lib/neo4j/import/accounts.csv `
  --nodes=Device=/var/lib/neo4j/import/devices.csv --relationships=OWNS=/var/lib/neo4j/import/owns.csv `
  --relationships=USED_DEVICE=/var/lib/neo4j/import/account_devices.csv --relationships=TRANSFER=/var/lib/neo4j/import/transfers.csv
docker compose start neo4j
Get-Content neo4j_setup.cypher | docker exec -i mm_neo4j cypher-shell -u neo4j -p $env:NEO4J_PASSWORD   # constraints + range index
python check_transfer_ids.py                  # unique transfer_id check
Remove-Item import\*.csv                      # remove temporary import copies
```

### 4. Inspect and answer Q1–Q7 (3.3, Sections 4–5; both services running)
```powershell
python q1.py; python q2.py; python q3.py
python q4.py; python q4_summary.py
python q5.py; python q6.py
python q7.py; python q7_paths.py
```

### 5. Correctness, 61 cases (6.1)
```powershell
python compare.py     # 61/61 cases, Q7 paths, independent CSV checks
```

### 6. Timing, one service at a time (6.2)
```powershell
docker compose stop neo4j;    python timing.py pg
docker compose stop postgres; docker compose start neo4j; python timing.py neo
python timing_summary.py
```
EXPLAIN (ANALYZE, BUFFERS) and PROFILE plans for Q2, Q4 B depth 10 and Q7 B bound 6 are in `results/plans/`.

### 7. SQL improvement (6.3; PostgreSQL only)
```powershell
docker compose stop neo4j; docker compose start postgres
python q7_v2.py       # PG["Q7_v2"] bidirectional search: 12-case recheck + B/E timings at bounds 4 and 6
```

### 8. Concurrent load test (7.1–7.2; one service at a time)
```powershell
python loadtest.py pg                                              # PostgreSQL running alone
docker compose stop postgres; docker compose start neo4j
python loadtest.py neo                                             # Neo4j running alone
python load_plot.py                                                # results/7.2_load_plots.png
```

### 9. Investigation diagrams (8.1)
```powershell
python diagrams_8_1.py
```

### 10. Stop the services (9.2)
```powershell
docker compose stop
```

## Files
| File | Section | Purpose |
|---|---|---|
| `mobile_money_generator.py` | 1.2 | Supplied generator, unchanged (SHA256 `2EA0E59D2B7B987D84A3D151BD9D1AD7B3052BFBC25ABF1466C8E94467E9455A`) |
| `capture.py` | 1.2 | Streams the five generator streams to CSV with audit totals |
| `docker-compose.yml` | 1.1 | PostgreSQL 16 and Neo4j 5 settings (memory, CPUs, time zone) |
| `pg_01_schema_load.sql`, `pg_02_constraints_indexes.sql`, `pg_03_checks.sql` | 2.1–2.2 | Tables, load, constraints, indexes, checks |
| `prepare_import.py`, `neo4j_setup.cypher` | 3.2 | Neo4j import files, constraints and index |
| `check_transfer_ids.py` | 3.2 | Unique `transfer_id` check in Neo4j |
| `common.py`, `cases.py` | 4–6 | Connections, `run_pg`/`run_neo`, review sets A–F, every SQL/Cypher query (`PG["Q7"]` original, `PG["Q7_v2"]` improved) |
| `q1.py` … `q7.py`, `q4_summary.py`, `q7_paths.py` | 3.3–5 | Paired questions and result files |
| `compare.py` | 6.1, 9.2 | 61-case comparison and independent CSV checks |
| `timing.py`, `timing_summary.py` | 6.2 | Warm-ups, measured runs, medians and ratios |
| `q7_v2.py` | 6.3 | Improved SQL recheck and retiming |
| `loadtest.py`, `load_plot.py` | 7 | Multiprocessing load test and scaling plots |
| `diagrams_8_1.py` | 8.1 | Transfer-cycle and ownership-device diagrams |
| `results/` | all | Full outputs, raw timing and load-test runs, plans, charts |

## Notes
- CSVs (`data/`, `import/`) and database stores are kept local and are not in this repository; `capture.py` regenerates the CSVs.
- All logged times are CAT (`start_cat` columns). Screenshot clocks show the PC's local time zone.
- Sizes use 1 GB = 1,000,000,000 bytes.