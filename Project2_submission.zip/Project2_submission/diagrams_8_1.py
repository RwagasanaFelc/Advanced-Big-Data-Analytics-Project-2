﻿import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = "results/"
INK, MUTED = "#1f2933", "#52606d"
ACC, CUS, DEV, HOT = "#2563eb", "#0f766e", "#7c3aed", "#c2410c"

def box(ax, x, y, text, color, w=2.2, h=0.9, fill=None, lw=1.6, bold=False, fs=10.5):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.02,rounding_size=0.12",
                                linewidth=lw, edgecolor=color, facecolor=fill or "white", zorder=3))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, color=INK, zorder=4,
            fontweight="bold" if bold else "normal", linespacing=1.3)

def arrow(ax, a, b, color=INK, lw=1.6):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=16, color=color, lw=lw,
                                 zorder=2, shrinkA=0, shrinkB=0))

def label(ax, x, y, text, color, **kw):
    ax.text(x, y, text, fontsize=kw.pop("fs", 9), color=color, zorder=5,
            bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"), **kw)

# ---------- Diagram 1: transfer cycle, set A ----------
fig, ax = plt.subplots(figsize=(12, 7.2))
ax.set_xlim(0, 12); ax.set_ylim(0, 7.2); ax.axis("off")
L, R, T, B = 2.2, 9.8, 5.4, 1.6
box(ax, L, T, "Account 998\nreview account (set A)\ncustomer 998, Kigali", HOT, w=3.0, h=1.15, fill="#fff7ed", lw=2.2, bold=True)
box(ax, R, T, "Account 8917\ncustomer 8917, Kigali", ACC, w=3.0, h=1.0)
box(ax, R, B, "Account 16836\ncustomer 16836, Northern", ACC, w=3.0, h=1.0)
box(ax, L, B, "Account 24755\ncustomer 24755, Northern\n(Q7 destination for A)", ACC, w=3.0, h=1.15)
arrow(ax, (L + 1.55, T), (R - 1.55, T))
ax.text(6.0, T + 0.3, "(1) transfer 20000001\n10:00:00 CAT | 200,000 RWF", ha="center", va="bottom", fontsize=9.5, color=INK)
arrow(ax, (R, T - 0.55), (R, B + 0.55))
ax.text(R - 0.2, 3.5, "(2) transfer 20000002\n10:00:40 | 196,000 RWF\n+40 s | 98.0% of (1)", ha="right", va="center", fontsize=9.5, color=INK)
arrow(ax, (R - 1.55, B), (L + 1.55, B))
ax.text(6.0, B - 0.3, "(3) transfer 20000003\n10:01:20 | 192,080 RWF | +40 s | 98.0% of (2)", ha="center", va="top", fontsize=9.5, color=INK)
arrow(ax, (L, B + 0.6), (L, T - 0.6), color=HOT, lw=2.4)
ax.text(L + 0.2, 3.5, "(4) transfer 20000004\n10:02:00 | 188,238 RWF\n+40 s | 98.0% of (3)\nreturns to 998", ha="left", va="center", fontsize=9.5, color=HOT)
ax.text(6.0, 3.5, "Q6 cycle: 4 transfers\nspan 120 s (limit 1,800 s)\nnet -11,762 RWF to 998\nQ5 chain = transfers (1)-(3)",
        ha="center", va="center", fontsize=9.5, color=MUTED, bbox=dict(boxstyle="round,pad=0.5", fc="#f5f7fa", ec="#cbd2d9"))
ax.text(6.0, 6.85, "Set A: circular transfer sequence on 6 September 2026 (CAT)", ha="center", fontsize=13, fontweight="bold", color=INK)
ax.text(6.0, 0.2, "Source: Q5/Q6 results (SQL and Cypher matched); owners and regions from the graph. "
        "A structural cycle does not prove the same funds moved.", ha="center", fontsize=8.5, color=MUTED)
fig.savefig(OUT + "8.1_diagram_cycle_A.png", dpi=170, bbox_inches="tight", facecolor="white")
plt.close(fig)

# ---------- Diagram 2: ownership and device links, set A ----------
fig, ax = plt.subplots(figsize=(13, 9))
ax.set_xlim(0, 12.6); ax.set_ylim(-0.9, 8.4); ax.axis("off")
yc, ya, ys, yd = 7.2, 5.0, 3.0, 0.9
ax.text(0.15, yc, "Customers", fontsize=9, color=CUS, va="center", fontweight="bold")
ax.text(0.15, ya, "Accounts", fontsize=9, color=ACC, va="center", fontweight="bold")
ax.text(0.15, yd, "Own\nhandsets", fontsize=9, color=DEV, va="center", fontweight="bold")
acct = {220998: 1.75, 998: 3.7, 8917: 5.75, 16836: 9.1, 24755: 11.3}
cust = {998: 2.72, 8917: 5.75, 16836: 9.1, 24755: 11.3}
region = {998: "Kigali", 8917: "Kigali", 16836: "Northern", 24755: "Northern"}
for c, x in cust.items():
    box(ax, x, yc, f"Customer {c}\n{region[c]}", CUS, w=1.9, h=0.9, fs=10)
for a, x in acct.items():
    if a == 998:
        box(ax, x, ya, "Account 998\nreview (A)", HOT, w=1.7, h=0.9, fill="#fff7ed", lw=2.2, bold=True, fs=10)
    else:
        box(ax, x, ya, f"Account\n{a}", ACC, w=1.7, h=0.9, fs=10)
for c, a in [(998, 998), (998, 220998), (8917, 8917), (16836, 16836), (24755, 24755)]:
    arrow(ax, (cust[c], yc - 0.45), (acct[a], ya + 0.45), color=CUS, lw=1.5)
label(ax, 1.55, 6.15, "OWNS", CUS, fs=8.5)
label(ax, 3.95, 6.15, "OWNS", CUS, fs=8.5)
SX = 7.35
box(ax, SX, ys, "Device 228001\nhandset\nshared by the four\ncycle accounts", HOT, w=2.2, h=1.25, fill="#fff7ed", lw=2.2, bold=True, fs=9.5)
dev = {"998": 2.72, "8917": 5.75, "16836": 9.1, "24751": 11.3}
for d, x in dev.items():
    box(ax, x, yd, f"Device {d}\nhandset", DEV, w=1.7, h=0.85, fs=9.5)
for a, d, obs in [(220998, "998", 25), (998, "998", 39), (8917, "8917", 53), (16836, "16836", 16), (24755, "24751", 30)]:
    x1, x2 = acct[a], dev[d]
    arrow(ax, (x1, ya - 0.45), (x2, yd + 0.425), color=DEV, lw=1.2)
    label(ax, x1 + (x2 - x1) * 0.72 + 0.08, (ya - 0.45) + ((yd + 0.425) - (ya - 0.45)) * 0.72, f"{obs}", DEV, fs=8.5)
targets = {998: (SX - 1.1, ys + 0.25), 8917: (SX - 0.6, ys + 0.62), 16836: (SX + 0.6, ys + 0.62), 24755: (SX + 1.1, ys + 0.25)}
for a, obs in [(998, 16), (8917, 13), (16836, 10), (24755, 7)]:
    xs, y1 = acct[a] + (0.35 if a in (998, 8917) else -0.35), ya - 0.45
    x2, y2 = targets[a]
    arrow(ax, (xs, y1), (x2, y2), color=HOT, lw=2.0)
    label(ax, xs + (x2 - xs) * 0.45 - 0.25, y1 + (y2 - y1) * 0.45, f"{obs} obs", HOT, fs=8.5, fontweight="bold")
ax.text(6.3, 8.15, "Set A: ownership and device links around review account 998", ha="center", fontsize=13, fontweight="bold", color=INK)
ax.text(6.3, -0.55,
        "Green: Customer -OWNS-> Account.  Purple: Account -USED_DEVICE-> own handset.  Orange: USED_DEVICE -> shared handset 228001.\n"
        "Numbers = observations; every interval covers days 0-29. Overlap does not prove simultaneous use, "
        "and observations do not show which device initiated a payment.", ha="center", fontsize=8.5, color=MUTED)
fig.savefig(OUT + "8.1_diagram_ownership_device_A.png", dpi=170, bbox_inches="tight", facecolor="white")
plt.close(fig)
print("Saved results/8.1_diagram_cycle_A.png and results/8.1_diagram_ownership_device_A.png")
