﻿import csv
import matplotlib.pyplot as plt

rows = []
for e in ("pg", "neo"):
    rows += list(csv.DictReader(open(f"results/load_summary_{e}.csv")))
ENG = {"pg": "PostgreSQL (Q7 = SQL v2)", "neo": "Neo4j"}
WL = {"Q4_d10": "Q4 ownership/device network, depth 10",
      "Q7_b6": "Q7 shortest transfer route, bound 6 (length only)"}

def get(e, wl):
    return sorted([r for r in rows if r["engine"] == e and r["workload"] == wl], key=lambda r: int(r["clients"]))

fig, ax = plt.subplots(2, 2, figsize=(13, 9))
for j, wl in enumerate(WL):
    for e, mk in (("pg", "o"), ("neo", "s")):
        r = get(e, wl)
        c = [int(x["clients"]) for x in r]
        ax[0][j].plot(c, [float(x["throughput"]) for x in r], marker=mk, label=ENG[e])
        ax[1][j].plot(c, [float(x["p95_ms"]) for x in r], marker=mk, label=ENG[e])
    ax[0][j].set_title(WL[wl] + "\nThroughput")
    ax[0][j].set_ylabel("Correct completions per second (req/s)")
    ax[1][j].set_title(WL[wl] + "\np95 latency")
    ax[1][j].set_ylabel("p95 latency (ms, log scale)")
    ax[1][j].set_yscale("log")
    for a in (ax[0][j], ax[1][j]):
        a.set_xlabel("Concurrent clients")
        a.set_xticks([1, 4, 8, 16])
        a.grid(True, alpha=0.3)
        a.legend()
fig.suptitle("Section 7.2 load test: median of 3 repetitions, 15 s window, A-B-C cycle, Docker limit 4 CPUs")
fig.tight_layout()
fig.savefig("results/7.2_load_plots.png", dpi=150)

print("1 vs 16 clients (median of 3 repetitions)")
print("engine workload | thr 1    thr 16   x     | p95 1     p95 16    x")
for e in ("pg", "neo"):
    for wl in WL:
        r = {int(x["clients"]): x for x in get(e, wl)}
        t1, t16 = float(r[1]["throughput"]), float(r[16]["throughput"])
        p1, p16 = float(r[1]["p95_ms"]), float(r[16]["p95_ms"])
        print(f"{e:<6} {wl:<8} | {t1:7.1f} {t16:8.1f} {t16/t1:5.1f}x | {p1:8.1f} {p16:8.1f} {p16/p1:5.1f}x")
print("\nNeo4j / PostgreSQL throughput ratio by client count")
for wl in WL:
    pg = {int(x["clients"]): float(x["throughput"]) for x in get("pg", wl)}
    neo = {int(x["clients"]): float(x["throughput"]) for x in get("neo", wl)}
    print(f"{wl:<8} " + "  ".join(f"{n:>2} clients: {neo[n]/pg[n]:5.1f}x" for n in (1, 4, 8, 16)))
print("Saved results/7.2_load_plots.png")
