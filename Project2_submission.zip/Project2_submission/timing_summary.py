﻿import csv, statistics
rows = {}
order = []
for eng in ("pg", "neo"):
    for r in csv.DictReader(open(f"results/timing_raw_{eng}.csv")):
        if r["phase"] != "measured":
            continue
        rows.setdefault((r["case"], eng), []).append(r)
        if r["case"] not in order:
            order.append(r["case"])

def st(c, e):
    rs = rows[(c, e)]
    ok = [float(r["seconds"]) * 1000 for r in rs if r["status"] == "ok"]
    if not ok:
        return None, None, None, len(rs)
    return statistics.median(ok), min(ok), max(ok), len(rs) - len(ok)

print("Q timing summary, milliseconds, 5 measured runs per case (ratio = PostgreSQL median / Neo4j median)")
print(f"{'case':<11}| {'PG median':>10} {'min':>9} {'max':>9} | {'Neo median':>10} {'min':>9} {'max':>9} | {'ratio':>7} | errors")
out = []
for c in order:
    p, n = st(c, "pg"), st(c, "neo")
    ratio = round(p[0] / n[0], 3) if p[0] and n[0] else None
    print(f"{c:<11}| {p[0]:>10.1f} {p[1]:>9.1f} {p[2]:>9.1f} | {n[0]:>10.1f} {n[1]:>9.1f} {n[2]:>9.1f} | {str(ratio):>7} | {p[3]}/{n[3]}")
    out.append([c, *[round(x, 1) for x in p[:3]], *[round(x, 1) for x in n[:3]], ratio, p[3], n[3]])
with open("results/timing_summary.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["case", "pg_median_ms", "pg_min_ms", "pg_max_ms", "neo_median_ms", "neo_min_ms", "neo_max_ms", "ratio_pg_over_neo", "pg_errors", "neo_errors"])
    w.writerows(out)
print(f"\n{len(out)} cases | saved results/timing_summary.csv")
