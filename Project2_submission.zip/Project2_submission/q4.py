﻿import json, os, sys, time
from common import SETS, pg_conn, neo_driver

SQL = """WITH RECURSIVE edges(sk, si, dk, di) AS (
  SELECT 'Customer'::text, customer_id, 'Account'::text, account_id FROM accounts
  UNION ALL SELECT 'Account'::text, account_id, 'Customer'::text, customer_id FROM accounts
  UNION ALL SELECT 'Account'::text, account_id, 'Device'::text, device_id FROM account_devices
  UNION ALL SELECT 'Device'::text, device_id, 'Account'::text, account_id FROM account_devices
), walk(kind, id, depth) AS (
  SELECT 'Account'::text, %(account)s::integer, 0
  UNION
  SELECT e.dk, e.di, w.depth + 1
  FROM walk w JOIN edges e ON e.sk = w.kind AND e.si = w.id
  WHERE w.depth < %(depth)s
)
SELECT c.region, COUNT(DISTINCT w.id) AS accounts
FROM walk w
JOIN accounts ac ON ac.account_id = w.id
JOIN customers c ON c.customer_id = ac.customer_id
WHERE w.kind = 'Account' AND w.id <> %(account)s
GROUP BY c.region ORDER BY c.region"""

# Cypher cannot take the path bound as a parameter, so the integer depth is placed in the text.
CYPHER = """MATCH (a:Account {account_id: $account})
MATCH (a)-[:OWNS|USED_DEVICE*1..__N__]-(b:Account)
WITH DISTINCT b
WHERE b.account_id <> $account
MATCH (c:Customer)-[:OWNS]->(b)
RETURN c.region AS region, count(*) AS accounts
ORDER BY region"""

def pg_run(account, depth):
    with pg_conn().cursor() as cur:
        cur.execute("SET statement_timeout = 170000")
        cur.execute(SQL, dict(account=account, depth=depth))
        return [list(r) for r in cur.fetchall()]

def neo_run(account, depth):
    q = CYPHER.replace("__N__", str(int(depth)))
    with neo_driver().session(database="neo4j") as s:
        return [list(r.values()) for r in s.run(q, {"account": account}, timeout=170)]

def timed(fn, *a):
    t0 = time.perf_counter()
    try:
        rows, status = fn(*a), "ok"
    except Exception as e:
        rows, status = None, "error: " + type(e).__name__
    return rows, status, time.perf_counter() - t0

depths = [int(x) for x in sys.argv[1:]]
path = "results/q4_results.json"
store = json.load(open(path)) if os.path.exists(path) else {}

print("Q4 distinct accounts linked through OWNS / USED_DEVICE (either direction), by owner region")
for depth in depths:
    for name, s in SETS.items():
        pg, ps, pt = timed(pg_run, s["account"], depth)
        ne, ns, nt = timed(neo_run, s["account"], depth)
        ok = ps == "ok" and ns == "ok" and pg == ne
        store[f"{name}-{depth}"] = dict(set=name, account=s["account"], depth=depth,
            sql=pg, neo=ne, sql_status=ps, neo_status=ns, sql_sec=round(pt, 2),
            neo_sec=round(nt, 2), match=ok)
        tp = sum(r[1] for r in pg) if pg is not None else ps
        tn = sum(r[1] for r in ne) if ne is not None else ns
        print(f"{name} {s['account']:>7} depth {depth:>2} | SQL {tp} accounts {pt:6.1f}s | Neo {tn} accounts {nt:6.1f}s | match {ok}")
        if pg is not None:
            print("      regions:", {r[0]: r[1] for r in pg})
        json.dump(store, open(path, "w"), indent=1)
print("saved", path)
