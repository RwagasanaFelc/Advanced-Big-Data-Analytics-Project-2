﻿import csv, json, math, os, statistics, subprocess, sys, time
import multiprocessing as mp

CLIENTS = (1, 4, 8, 16)
REPS = 3
WINDOW = 15
LIMIT = 60
LABELS = ("A", "B", "C")
WORKLOADS = ("Q4_d10", "Q7_b6")
CONTAINER = {"pg": "mm_postgres", "neo": "mm_neo4j"}


def make_params(workload, label):
    from common import SETS
    s = SETS[label]
    if workload == "Q4_d10":
        return dict(account=s["account"], depth=10)
    return dict(account=s["account"], dest=s["dest"], bound=6)


def canon(workload, rows):
    if workload == "Q7_b6":
        return rows[0][0] if rows else None
    return sorted(list(r) for r in rows)


def make_runner(engine, workload):
    import cases as C
    from common import pg_conn, neo_driver, norm
    if engine == "pg":
        q = C.PG["Q4"] if workload == "Q4_d10" else C.PG["Q7_v2"]
        conn = pg_conn()
        with conn.cursor() as cur:
            cur.execute("SET statement_timeout = %s", (LIMIT * 1000,))
        def run(p):
            with conn.cursor() as cur:
                cur.execute(q, p)
                return [tuple(norm(v) for v in r) for r in cur.fetchall()]
        return run, (lambda: None)
    from neo4j import Query
    text = C.NEO["Q4"] if workload == "Q4_d10" else C.NEO["Q7"]
    sess = neo_driver().session(database="neo4j")
    def run(p):
        t = text.replace("__N__", str(int(p.get("depth") or p.get("bound"))))
        return [tuple(norm(v) for v in rec.values()) for rec in sess.run(Query(t, timeout=LIMIT), p)]
    return run, sess.close


def classify(e, dt):
    msg = (type(e).__name__ + " " + str(e)).lower()
    if dt >= 0.9 * LIMIT or "querycanceled" in msg or "timeout" in msg or "timedout" in msg:
        return "timeout"
    return "error: " + type(e).__name__


def worker(engine, workload, cid, barrier, start_val, out):
    run, close, setup_err = None, (lambda: None), ""
    plist = [(lab, make_params(workload, lab)) for lab in LABELS]
    try:
        run, close = make_runner(engine, workload)
        for lab, p in plist:          # warm-up A-B-C once
            run(p)
    except Exception as e:
        run, setup_err = None, f"{type(e).__name__}: {e}"
    idx = barrier.wait()
    if idx == 0:
        start_val.value = time.time()  # common start time at barrier release
    while start_val.value == 0.0:
        pass
    start = start_val.value
    deadline = start + WINDOW
    log, cycle = [], 0
    while run is not None and time.time() < deadline:   # start cycles until the deadline
        cycle += 1
        for lab, p in plist:                             # finish any started cycle
            off = time.time() - start
            t0 = time.perf_counter()
            try:
                res, status = json.dumps(canon(workload, run(p))), "ok"
            except Exception as e:
                res, status = "", classify(e, time.perf_counter() - t0)
            dt = time.perf_counter() - t0
            if status == "ok" and dt >= LIMIT:
                status = "timeout"
            log.append((cid, cycle, lab, round(off, 4), round(dt * 1000, 3), status, res))
    end = time.time()
    try:
        close()
    except Exception:
        pass
    out.put((cid, end, log, setup_err))


def make_sampler(engine):
    if engine == "pg":
        from common import pg_conn
        def active():
            with pg_conn().cursor() as cur:
                cur.execute("""SELECT count(*) FILTER (WHERE state = 'active'), count(*)
                               FROM pg_stat_activity
                               WHERE datname = 'mobilemoney' AND backend_type = 'client backend'
                                 AND pid <> pg_backend_pid()""")
                a, c = cur.fetchone()
            return f"{a} running/{c} connected"
    else:
        from common import neo_driver
        def active():
            with neo_driver().session(database="neo4j") as s:
                rec = s.run("SHOW TRANSACTIONS YIELD currentQuery "
                            "WHERE NOT currentQuery STARTS WITH 'SHOW TRANSACTIONS' "
                            "RETURN count(*) AS n").single()
            return f"{rec['n']} running tx"
    def sample():
        try:
            act = active()
        except Exception as e:
            act = "n/a (" + type(e).__name__ + ")"
        try:
            r = subprocess.run(["docker", "stats", "--no-stream", "--format",
                                "{{.CPUPerc}} {{.MemUsage}}", CONTAINER[engine]],
                               capture_output=True, text=True, timeout=30)
            cpu = r.stdout.strip() or "n/a"
        except Exception:
            cpu = "n/a"
        return act, cpu
    return sample


def reference(engine):
    ref = {}
    for wl in WORKLOADS:
        run, close = make_runner(engine, wl)
        for lab in LABELS:
            ref[f"{wl}-{lab}"] = json.dumps(canon(wl, run(make_params(wl, lab))))
        close()
    return ref


def run_rep(engine, workload, n, ref, sample, req_writer, rep):
    barrier, start_val, out = mp.Barrier(n), mp.Value("d", 0.0), mp.Queue()
    procs = [mp.Process(target=worker, args=(engine, workload, i + 1, barrier, start_val, out))
             for i in range(n)]
    for p in procs:
        p.start()
    t_wait = time.time()
    while start_val.value == 0.0:
        if time.time() - t_wait > 600:
            for p in procs:
                p.terminate()
            raise RuntimeError("clients did not reach the barrier")
        time.sleep(0.02)
    start = start_val.value
    time.sleep(max(0.0, start + WINDOW / 2 - time.time()))
    act, cpu = sample()                                   # mid-window evidence
    got = [out.get(timeout=WINDOW + 3 * LIMIT + 120) for _ in range(n)]
    for p in procs:
        p.join()
    entries, ends, setup_errs = [], [], []
    for cid, end, log, err in got:
        ends.append(end)
        entries.extend(log)
        if err:
            setup_errs.append(f"client {cid}: {err}")
    elapsed = max(ends) - start
    ok = [e for e in entries if e[5] == "ok"]
    correct = [e for e in ok if e[6] == ref[f"{workload}-{e[2]}"]]
    for e in entries:
        is_ok = e[5] == "ok" and e[6] == ref[f"{workload}-{e[2]}"]
        req_writer.writerow([engine, workload, n, rep, *e[:6], is_ok, e[6]])
    lat = sorted(e[4] for e in ok)
    return dict(engine=engine, workload=workload, clients=n, rep=rep,
                requests=len(entries), ok=len(ok), correct=len(correct),
                wrong=len(ok) - len(correct),
                errors=sum(1 for e in entries if e[5].startswith("error")),
                timeouts=sum(1 for e in entries if e[5] == "timeout"),
                elapsed_s=round(elapsed, 3),
                throughput=round(len(correct) / elapsed, 2) if elapsed > 0 else 0,
                median_ms=round(statistics.median(lat), 2) if lat else None,
                p95_ms=round(lat[math.ceil(0.95 * len(lat)) - 1], 2) if lat else None,
                active_mid=act, docker_mid=cpu, setup_errors="; ".join(setup_errs))


def main():
    engine = sys.argv[1]
    assert engine in ("pg", "neo")
    os.makedirs("results", exist_ok=True)
    print(f"Load test {engine}: workloads {WORKLOADS}, clients {CLIENTS}, {REPS} reps, "
          f"{WINDOW} s window, {LIMIT} s timeout, cycle A-B-C. Machine logical CPUs: {os.cpu_count()}", flush=True)
    ref = reference(engine)
    json.dump(ref, open(f"results/load_reference_{engine}.json", "w"), indent=1)
    print("Reference answers (uncontested):", flush=True)
    for k, v in ref.items():
        print(f"  {k}: {v}", flush=True)
    other = "neo" if engine == "pg" else "pg"
    if os.path.exists(f"results/load_reference_{other}.json"):
        print("Cross-engine reference match:", ref == json.load(open(f"results/load_reference_{other}.json")), flush=True)
    sample = make_sampler(engine)
    reps = []
    with open(f"results/load_requests_{engine}.csv", "w", newline="") as rf:
        rw = csv.writer(rf)
        rw.writerow(["engine", "workload", "clients", "rep", "client", "cycle", "label",
                     "submit_offset_s", "latency_ms", "status", "correct", "result"])
        print("\nworkload clients rep | requests correct wrong err to | throughput req/s | median ms |    p95 ms | active (mid-window) | container CPU% mem", flush=True)
        for wl in WORKLOADS:
            for n in CLIENTS:
                for rep in range(1, REPS + 1):
                    r = run_rep(engine, wl, n, ref, sample, rw, rep)
                    rf.flush()
                    reps.append(r)
                    print(f"{wl:<8} {n:>7} {rep:>3} | {r['requests']:>8} {r['correct']:>7} {r['wrong']:>5} {r['errors']:>3} {r['timeouts']:>2} | "
                          f"{r['throughput']:>16.1f} | {r['median_ms']:>9} | {r['p95_ms']:>9} | {r['active_mid']:<19} | {r['docker_mid']}", flush=True)
                    if r["setup_errors"]:
                        print("   SETUP ERRORS:", r["setup_errors"], flush=True)
    with open(f"results/load_reps_{engine}.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(reps[0].keys()))
        w.writeheader()
        w.writerows(reps)
    summary = []
    print(f"\nSUMMARY {engine} (median of {REPS} repetitions)", flush=True)
    print("workload clients | throughput req/s | median ms |    p95 ms | errors timeouts wrong (total over reps)")
    for wl in WORKLOADS:
        for n in CLIENTS:
            rs = [r for r in reps if r["workload"] == wl and r["clients"] == n]
            def med(key):
                vals = [r[key] for r in rs if r[key] is not None]
                return round(statistics.median(vals), 2) if vals else None
            s = dict(engine=engine, workload=wl, clients=n, throughput=med("throughput"),
                     median_ms=med("median_ms"), p95_ms=med("p95_ms"),
                     errors=sum(r["errors"] for r in rs), timeouts=sum(r["timeouts"] for r in rs),
                     wrong=sum(r["wrong"] for r in rs))
            summary.append(s)
            print(f"{wl:<8} {n:>7} | {s['throughput']:>16} | {s['median_ms']:>9} | {s['p95_ms']:>9} | {s['errors']:>6} {s['timeouts']:>8} {s['wrong']:>5}")
    with open(f"results/load_summary_{engine}.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)
    print(f"\nSaved results/load_requests_{engine}.csv, load_reps_{engine}.csv, load_summary_{engine}.csv")


if __name__ == "__main__":
    main()
