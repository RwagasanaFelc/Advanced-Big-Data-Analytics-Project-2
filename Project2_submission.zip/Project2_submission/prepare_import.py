﻿import csv, os, shutil, time

SRC, DST = "data", "import"
os.makedirs(DST, exist_ok=True)

def retyped(src, dst, header):
    """Copy a source CSV with a new typed header; the source stays unchanged."""
    t0 = time.time()
    with open(os.path.join(SRC, src), "rb") as fi, open(os.path.join(DST, dst), "wb") as fo:
        fi.readline()
        fo.write((header + "\r\n").encode())
        shutil.copyfileobj(fi, fo, 16 * 1024 * 1024)
    print(f"{dst} written in {time.time()-t0:.0f}s", flush=True)

retyped("customers.csv", "customers.csv", "customer_id:ID(Customer),region:string")
retyped("accounts.csv", "accounts.csv", "account_id:ID(Account),:IGNORE,role:string")
retyped("devices.csv", "devices.csv", "device_id:ID(Device),access_type:string")
retyped("account_devices.csv", "account_devices.csv",
        ":START_ID(Account),:END_ID(Device),first_day:int,last_day:int,observations:int")
retyped("transfers.csv", "transfers.csv",
        "transfer_id:long,:START_ID(Account),:END_ID(Account),occurred_at:long,amount_rwf:long")

with open(os.path.join(SRC, "accounts.csv"), newline="", encoding="utf-8") as f:
    r = csv.reader(f)
    next(r)
    pairs = sorted((int(c), int(a)) for a, c, _role in r)
with open(os.path.join(DST, "owns.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow([":START_ID(Customer)", ":END_ID(Account)"])
    w.writerows(pairs)
print(f"owns.csv: {len(pairs):,} rows")
