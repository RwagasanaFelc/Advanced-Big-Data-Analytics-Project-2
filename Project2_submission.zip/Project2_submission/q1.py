﻿from common import SETS, hour_bounds, run_pg, run_neo

SQL = """SELECT COUNT(*), COALESCE(SUM(amount_rwf), 0)
FROM transfers WHERE sender_id = %(account)s
  AND occurred_at >= %(start)s AND occurred_at < %(end)s"""

CYPHER = """MATCH (a:Account {account_id: $account})-[t:TRANSFER]->()
WHERE t.occurred_at >= $start AND t.occurred_at < $end
RETURN count(t) AS n, coalesce(sum(t.amount_rwf), 0) AS total"""

print("Q1 outgoing transfers, 09:45:00 inclusive to 10:45:00 exclusive CAT")
print("Set Account  Sep  start_epoch   end_epoch | SQL count  SQL RWF | Neo count  Neo RWF | match")
for name, s in SETS.items():
    start, end = hour_bounds(s["day"])
    p = dict(account=s["account"], start=start, end=end)
    a = run_pg(SQL, p)[0]
    b = run_neo(CYPHER, p)[0]
    print(f"{name:<3} {s['account']:>7} {s['day']:>4} {start:>12} {end:>11} | {a[0]:>9} {a[1]:>8} | {b[0]:>9} {b[1]:>8} | {a == b}")
