﻿import csv
from collections import Counter
from common import SETS, run_pg, run_neo

SQL = """SELECT o.account_id AS other_account_id, a.device_id, d.access_type,
       GREATEST(a.first_day, o.first_day) AS overlap_start,
       LEAST(a.last_day, o.last_day) AS overlap_end
FROM account_devices a
JOIN account_devices o ON o.device_id = a.device_id AND o.account_id <> a.account_id
JOIN devices d ON d.device_id = a.device_id
WHERE a.account_id = %(account)s
  AND GREATEST(a.first_day, o.first_day) <= LEAST(a.last_day, o.last_day)
ORDER BY o.account_id, a.device_id"""

CYPHER = """MATCH (a:Account {account_id: $account})-[ua:USED_DEVICE]->(d:Device)<-[uo:USED_DEVICE]-(o:Account)
WHERE o.account_id <> $account
WITH o, d,
     CASE WHEN ua.first_day > uo.first_day THEN ua.first_day ELSE uo.first_day END AS s,
     CASE WHEN ua.last_day < uo.last_day THEN ua.last_day ELSE uo.last_day END AS e
WHERE s <= e
RETURN o.account_id AS other_account_id, d.device_id AS device_id, d.access_type AS access_type,
       s AS overlap_start, e AS overlap_end
ORDER BY other_account_id, device_id"""

print("Q3 accounts sharing a device with the review account during overlapping days")
print("Set Account | SQL rows  Neo rows | other accounts | access types           | match")
allrows = []
sample = None
for name, s in SETS.items():
    p = dict(account=s["account"])
    a = run_pg(SQL, p)
    b = run_neo(CYPHER, p)
    types = dict(Counter(r[2] for r in a))
    print(f"{name:<3} {s['account']:>7} | {len(a):>8} {len(b):>8} | {len({r[0] for r in a}):>14} | {str(types):<22} | {a == b}")
    for r in a:
        allrows.append((name, s["account"]) + r)
    if sample is None and a:
        sample = (name, s["account"], a[:6])

if sample:
    print()
    print(f"Sample rows, set {sample[0]} account {sample[1]} (other_account, device, access_type, overlap_start, overlap_end):")
    for r in sample[2]:
        print("  ", r)

with open("results/q3_full.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["set", "review_account", "other_account_id", "device_id", "access_type", "overlap_start", "overlap_end"])
    w.writerows(allrows)
print()
print("full rows saved to results/q3_full.csv:", len(allrows), "rows")
