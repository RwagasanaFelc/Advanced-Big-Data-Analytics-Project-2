﻿import json, time
from collections import Counter
from datetime import datetime
from common import SETS, CAT, hour_bounds, pg_conn, neo_driver

SQL = """WITH RECURSIVE walk(cur, ids, first_t, last_t, last_amt, n) AS (
  SELECT t.receiver_id, ARRAY[t.transfer_id], t.occurred_at, t.occurred_at, t.amount_rwf::bigint, 1
  FROM transfers t
  WHERE t.sender_id = %(account)s
    AND t.occurred_at >= %(start)s AND t.occurred_at < %(end)s
    AND t.receiver_id <> %(account)s
  UNION ALL
  SELECT t.receiver_id, w.ids || t.transfer_id, w.first_t, t.occurred_at, t.amount_rwf::bigint, w.n + 1
  FROM walk w JOIN transfers t ON t.sender_id = w.cur
  WHERE w.cur <> %(account)s
    AND w.n < 8
    AND t.occurred_at > w.last_t
    AND t.occurred_at < %(end)s
    AND t.occurred_at - w.first_t <= 1800
    AND 90 * w.last_amt <= 100 * t.amount_rwf::bigint
    AND 100 * t.amount_rwf::bigint <= 105 * w.last_amt
)
SELECT ids, n FROM walk WHERE cur = %(account)s AND n >= 3 ORDER BY ids"""

CYPHER = """MATCH p = (a:Account {account_id: $account})-[ts:TRANSFER*3..8]->(a)
WHERE all(r IN ts WHERE r.occurred_at >= $start AND r.occurred_at < $end)
  AND all(n IN nodes(p)[1..-1] WHERE n <> a)
  AND all(i IN range(0, size(ts) - 2) WHERE ts[i].occurred_at < ts[i + 1].occurred_at
        AND 90 * ts[i].amount_rwf <= 100 * ts[i + 1].amount_rwf
        AND 100 * ts[i + 1].amount_rwf <= 105 * ts[i].amount_rwf)
  AND ts[size(ts) - 1].occurred_at - ts[0].occurred_at <= 1800
RETURN [r IN ts | r.transfer_id] AS ids, size(ts) AS n
ORDER BY ids"""

def pg_run(p):
    with pg_conn().cursor() as cur:
        cur.execute("SET statement_timeout = 170000")
        cur.execute(SQL, p)
        return sorted((tuple(r[0]), r[1]) for r in cur.fetchall())

def neo_run(p):
    with neo_driver().session(database="neo4j") as s:
        return sorted((tuple(r["ids"]), r["n"]) for r in s.run(CYPHER, p, timeout=170))

def timed(fn, p):
    t0 = time.perf_counter()
    try:
        rows, st = fn(p), "ok"
    except Exception as e:
        rows, st = None, "error: " + type(e).__name__
    return rows, st, time.perf_counter() - t0

res, first = {}, None
print("Q6 circular payments: 3 to 8 transfers back to the review account, inside its hour, span <= 1800 s, Q5 amount rule")
print("Set Account | SQL cycles Neo cycles | lengths | match | SQL s  Neo s")
for name, s in SETS.items():
    start, end = hour_bounds(s["day"])
    p = dict(account=s["account"], start=start, end=end)
    a, sa, ta = timed(pg_run, p)
    b, sb, tb = timed(neo_run, p)
    ok = sa == "ok" and sb == "ok" and a == b
    res[name] = dict(account=s["account"], sql=a, neo=b, sql_status=sa, neo_status=sb, sql_sec=round(ta, 2), neo_sec=round(tb, 2), match=ok)
    na = len(a) if a is not None else sa
    nb = len(b) if b is not None else sb
    lens = dict(Counter(r[1] for r in a)) if a else {}
    print(f"{name:<3} {s['account']:>7} | {str(na):>10} {str(nb):>10} | {str(lens):<7} | {ok} | {ta:5.1f} {tb:6.1f}")
    if first is None and a:
        first = (name, s["account"], a[0])
json.dump(res, open("results/q6_results.json", "w"), indent=1)

print()
for name, r in res.items():
    for seq, n in (r["sql"] or [])[:3]:
        print(f"set {name} cycle length {n}: transfer ids {list(seq)}")

if first:
    name, acct, (seq, n) = first
    cur = pg_conn().cursor()
    cur.execute("SELECT transfer_id, sender_id, receiver_id, occurred_at, amount_rwf FROM transfers WHERE transfer_id = ANY(%s) ORDER BY occurred_at", (list(seq),))
    rows = cur.fetchall()
    print()
    print(f"Example cycle, set {name}, review account {acct}, {n} transfers:")
    prev = None
    for r in rows:
        when = datetime.fromtimestamp(r[3], CAT).strftime("%Y-%m-%d %H:%M:%S")
        extra = "" if prev is None else f" | +{r[3]-prev[3]} s, {100*r[4]/prev[4]:.2f}% of previous"
        print(f"  transfer {r[0]}: {r[1]} -> {r[2]} at {when} CAT, {r[4]:,} RWF{extra}")
        prev = r
    print(f"  span: {rows[-1][3]-rows[0][3]} s (limit 1800)")
