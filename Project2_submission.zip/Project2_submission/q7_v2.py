﻿import csv, json, os, statistics, time
from datetime import datetime
from common import SETS, CAT, pg_conn
import cases as C

SQL = C.PG["Q7_v2"]

def run(p, limit):
    with pg_conn().cursor() as cur:
        cur.execute("SET statement_timeout = %s", (limit * 1000,))
        cur.execute(SQL, p)
        return cur.fetchall()

def timed(p, limit):
    start = datetime.now(CAT).strftime("%Y-%m-%d %H:%M:%S")
    t0 = time.perf_counter()
    try:
        rows, status = run(p, limit), "ok"
    except Exception as e:
        rows, status = None, "error: " + type(e).__name__
    dt = time.perf_counter() - t0
    if dt >= limit or (status != "ok" and dt >= 0.9 * limit):
        rows, status = None, "timeout"
    value = rows[0][0] if rows else None
    return start, dt, (len(rows) if rows is not None else None), value, status

def params(s, bound):
    return dict(account=s["account"], dest=s["dest"], bound=bound)

def fmt(x, w=9):
    return f"{x:{w}.1f}" if x is not None else f"{'-':>{w}}"

# ---------- PART 1: correctness of v2 on all 12 cases ----------
old = json.load(open("results/q7_results.json"))
check, n_ok = {}, 0
print("PART 1  Q7 recheck: SQL v2 (bidirectional) vs original SQL v1 and Neo4j  (None = no route within the bound)")
print("Set Account   Dest Bound | SQL v1 | Neo4j | SQL v2    v2 ms | match")
for bound in (4, 6):
    for name, s in SETS.items():
        k = f"{name}-{bound}"
        _, dt, _, v2, st = timed(params(s, bound), 180)
        r = old.get(k, {})
        ok = st == "ok" and k in old and v2 == r.get("sql") and v2 == r.get("neo")
        n_ok += ok
        check[k] = dict(set=name, account=s["account"], dest=s["dest"], bound=bound,
                        sql_v1=r.get("sql"), neo=r.get("neo"), sql_v2=v2,
                        v2_status=st, v2_ms=round(dt * 1000, 1), match=ok)
        shown = v2 if st == "ok" else st
        print(f"{name:<3} {s['account']:>7} {s['dest']:>6} {bound:>5} | {str(r.get('sql')):>6} | {str(r.get('neo')):>5} | {str(shown):>6} {dt*1000:8.1f} | {ok}", flush=True)
json.dump(check, open("results/q7_v2_check.json", "w"), indent=1)
print(f"{n_ok}/12 cases match. Saved results/q7_v2_check.json\n", flush=True)

# ---------- PART 2: timing B/E at bounds 4 and 6 ----------
def old_medians(path, question):
    out = {}
    if not os.path.exists(path):
        return out
    for row in csv.DictReader(open(path)):
        if row["question"] == question and row["phase"] == "measured" and row["status"] == "ok":
            p = json.loads(row["params"])
            out.setdefault((p.get("account"), p.get("bound")), []).append(float(row["seconds"]) * 1000)
    return {k: statistics.median(v) for k, v in out.items()}

v1_med = old_medians("results/timing_raw_pg.csv", "Q7")
neo_med = old_medians("results/timing_raw_neo.csv", "Q7")

print("PART 2  Timing SQL v2: 3 warm-ups (180 s limit) + 5 measured runs (60 s limit), PostgreSQL only", flush=True)
summary = []
with open("results/timing_raw_pg_q7_v2.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["case", "question", "label", "params", "engine", "phase", "run", "start_cat", "seconds", "rows", "status"])
    for bound in (4, 6):
        for name in ("B", "E"):
            s = SETS[name]
            p = params(s, bound)
            label = f"{name}-b{bound}"
            ms = []
            for phase, runs, limit in (("warmup", 3, 180), ("measured", 5, 60)):
                for k in range(runs):
                    st, dt, n, _, status = timed(p, limit)
                    w.writerow([f"Q7_v2-{label}", "Q7_v2", label, json.dumps(p), "pg", phase, k + 1, st, round(dt, 4), n, status])
                    f.flush()
                    if phase == "measured" and status == "ok":
                        ms.append(dt * 1000)
            med = statistics.median(ms) if ms else None
            v1 = v1_med.get((s["account"], bound))
            nm = neo_med.get((s["account"], bound))
            summary.append(dict(set=name, bound=bound, v1_median_ms=v1,
                                v2_median_ms=med, v2_min_ms=min(ms) if ms else None,
                                v2_max_ms=max(ms) if ms else None, completed=len(ms),
                                speedup=(v1 / med) if (v1 and med) else None,
                                neo_median_ms=nm, pg_v2_neo_ratio=(med / nm) if (med and nm) else None))

print("Set Bound | v1 median ms | v2 median    v2 min    v2 max | ok  | speed-up | Neo4j median | PG v2/Neo ratio")
for r in summary:
    print(f"{r['set']:<3} {r['bound']:>5} | {fmt(r['v1_median_ms'], 12)} | {fmt(r['v2_median_ms'])} {fmt(r['v2_min_ms'])} {fmt(r['v2_max_ms'])} | {r['completed']}/5 | {fmt(r['speedup'], 7)}x | {fmt(r['neo_median_ms'], 12)} | {fmt(r['pg_v2_neo_ratio'], 8)}")
with open("results/q7_v2_timing_summary.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
    w.writeheader()
    w.writerows(summary)
print("Saved results/timing_raw_pg_q7_v2.csv and results/q7_v2_timing_summary.csv")
