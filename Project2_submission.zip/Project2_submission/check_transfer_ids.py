import os
import time
from array import array
import numpy as np
from neo4j import GraphDatabase

t0 = time.perf_counter()
drv = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", os.environ.get("NEO4J_PASSWORD", "CHANGE_ME")))
ids = array("q")
with drv.session(database="neo4j") as s:
    for r in s.run("MATCH ()-[t:TRANSFER]->() RETURN t.transfer_id AS id"):
        ids.append(r["id"])
drv.close()
a = np.sort(np.frombuffer(ids, dtype=np.int64))
dups = int((a[1:] == a[:-1]).sum())
print("transfer_id rows:", len(a), "| duplicates:", dups,
      "| min:", int(a[0]), "| max:", int(a[-1]),
      "| seconds:", round(time.perf_counter() - t0, 1))
