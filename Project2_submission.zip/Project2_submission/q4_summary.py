﻿import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = json.load(open("results/q4_results.json"))
def total(r):
    return sum(x[1] for x in r) if r is not None else None

keys = sorted(d, key=lambda k: (d[k]["set"], d[k]["depth"]))
print("Q4 all comparisons: distinct accounts within N links (SQL vs Neo4j)")
print("Set Account  Depth | SQL accounts  Neo accounts | regions | SQL s   Neo s | match")
for k in keys:
    r = d[k]
    print(f"{r['set']:<3} {r['account']:>7} {r['depth']:>6} | {str(total(r['sql'])):>12} {str(total(r['neo'])):>13} | "
          f"{len(r['sql'] or []):>7} | {r['sql_sec']:>5.1f} {r['neo_sec']:>6.1f} | {r['match']}")
ok = sum(1 for r in d.values() if r["match"])
err = sum(1 for r in d.values() if r["sql_status"] != "ok" or r["neo_status"] != "ok")
print(f"\ncomparisons: {len(d)} | matching: {ok} | errors/timeouts: {err}")

fig, ax = plt.subplots(figsize=(9, 5.5))
marks = dict(A="o", B="s", C="^", D="x", E="d", F="v")
for s in "ABCDEF":
    pts = sorted((r["depth"], total(r["sql"])) for r in d.values() if r["set"] == s)
    ax.plot([p[0] for p in pts], [p[1] for p in pts], marker=marks[s], label=f"Set {s}")
ax.set_xticks([4, 6, 8, 10])
ax.set_xlabel("Maximum number of links (depth)")
ax.set_ylabel("Distinct other accounts reached (count)")
ax.set_title("Q4 network size grows with depth, then saturates")
ax.legend()
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig("results/q4_chart.png", dpi=120)
print("saved results/q4_chart.png")
