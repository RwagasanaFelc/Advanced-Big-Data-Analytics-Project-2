\timing on
SET timezone TO 'Africa/Kigali';
SHOW timezone;

DROP TABLE IF EXISTS transfers, account_devices, devices, accounts, customers CASCADE;

CREATE TABLE customers (
  customer_id INTEGER PRIMARY KEY,
  region      TEXT NOT NULL
);
CREATE TABLE accounts (
  account_id  INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL,
  role        TEXT NOT NULL
);
CREATE TABLE devices (
  device_id   INTEGER PRIMARY KEY,
  access_type TEXT NOT NULL
);
CREATE TABLE account_devices (
  account_id   INTEGER  NOT NULL,
  device_id    INTEGER  NOT NULL,
  first_day    SMALLINT NOT NULL,
  last_day     SMALLINT NOT NULL,
  observations INTEGER  NOT NULL CHECK (observations > 0),
  PRIMARY KEY (account_id, device_id),
  CHECK (0 <= first_day AND first_day <= last_day AND last_day <= 29)
);
CREATE TABLE transfers (
  transfer_id BIGINT  PRIMARY KEY,
  sender_id   INTEGER NOT NULL,
  receiver_id INTEGER NOT NULL,
  occurred_at BIGINT  NOT NULL,
  amount_rwf  INTEGER NOT NULL CHECK (amount_rwf > 0)
);

\echo === LOAD ===
\copy customers       FROM '/tmp/customers.csv'       CSV HEADER
\copy devices         FROM '/tmp/devices.csv'         CSV HEADER
\copy accounts        FROM '/tmp/accounts.csv'        CSV HEADER
\copy account_devices FROM '/tmp/account_devices.csv' CSV HEADER
\copy transfers       FROM '/tmp/transfers.csv'       CSV HEADER
