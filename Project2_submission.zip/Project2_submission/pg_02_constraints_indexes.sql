\timing on
\echo === CONSTRAINTS AND INDEXES ===
ALTER TABLE accounts        ADD FOREIGN KEY (customer_id) REFERENCES customers(customer_id);
ALTER TABLE account_devices ADD FOREIGN KEY (account_id)  REFERENCES accounts(account_id);
ALTER TABLE account_devices ADD FOREIGN KEY (device_id)   REFERENCES devices(device_id);
ALTER TABLE transfers       ADD FOREIGN KEY (sender_id)   REFERENCES accounts(account_id);
ALTER TABLE transfers       ADD FOREIGN KEY (receiver_id) REFERENCES accounts(account_id);

CREATE INDEX ON accounts (customer_id, account_id);
CREATE INDEX ON account_devices (device_id, account_id);
CREATE INDEX ON transfers (sender_id, occurred_at)   INCLUDE (receiver_id, amount_rwf, transfer_id);
CREATE INDEX ON transfers (receiver_id, occurred_at) INCLUDE (sender_id, amount_rwf, transfer_id);
CREATE INDEX ON transfers USING BRIN (occurred_at);
ANALYZE;
