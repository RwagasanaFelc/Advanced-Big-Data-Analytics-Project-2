﻿import csv, json, statistics, sys, time
from datetime import datetime
from neo4j import Query
from common import CAT, pg_conn, neo_driver
import cases as C

engine = sys.argv[1]
assert engine in ("pg", "neo")

def selected(q, label):
    if q in ("Q1", "Q3", "Q5", "Q6"):
        return label in ("B", "E")
    if q == "Q2":
        return True
    return label.split("-")[0] in ("B", "E")

cases = [c for c in C.all_cases() if selected(c[0], c[1])]
assert len(cases) == 21, len(cases)

pgc = pg_conn() if engine == "pg" else None
sess = neo_driver().session(database="neo4j") if engine == "neo" else None

def run_once(q, p, limit):
    if engine == "pg":
        with pgc.cursor() as cur:
            cur.execute("SET statement_timeout = %s", (limit * 1000,))
            cur.execute(C.PG[q], p)
            return len(cur.fetchall())
    text = C.NEO[q]
    if "__N__" in text:
        text = text.replace("__N__", str(int(p.get("depth") or p.get("bound"))))
    return len(list(sess.run(Query(text, timeout=limit), p)))

def timed(q, p, limit):
    start = datetime.now(CAT).strftime("%Y-%m-%d %H:%M:%S")
    t0 = time.perf_counter()
    try:
        n, status = run_once(q, p, limit), "ok"
    except Exception as e:
        n, status = None, "error: " + type(e).__name__
    dt = time.perf_counter() - t0
    if dt >= limit or (status != "ok" and dt >= 0.9 * limit):
        n, status = None, "timeout"
    return start, dt, n, status

T0 = time.perf_counter()
print(f"Timing {engine}: 21 cases, 3 warm-ups (180 s limit) + 5 measured runs (60 s limit)", flush=True)
with open(f"results/timing_raw_{engine}.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["case", "question", "label", "params", "engine", "phase", "run", "start_cat", "seconds", "rows", "status"])
    for i, (q, label, p) in enumerate(cases, 1):
        print(f"[{i}/21] {q}-{label} running...", flush=True)
        ms = []
        for phase, runs, limit in (("warmup", 3, 180), ("measured", 5, 60)):
            for k in range(runs):
                st, dt, n, s = timed(q, p, limit)
                w.writerow([f"{q}-{label}", q, label, json.dumps(p), engine, phase, k + 1, st, round(dt, 4), n, s])
                f.flush()
                if phase == "measured" and s == "ok":
                    ms.append(dt * 1000)
        if ms:
            print(f"      median {statistics.median(ms):10.1f} ms | min {min(ms):10.1f} | max {max(ms):10.1f} | completed {len(ms)}/5 | errors/timeouts {5 - len(ms)}", flush=True)
        else:
            print("      no completed measured runs (5 errors/timeouts)", flush=True)
print(f"DONE in {(time.perf_counter() - T0) / 60:.1f} minutes. Raw runs saved in results/timing_raw_{engine}.csv")
