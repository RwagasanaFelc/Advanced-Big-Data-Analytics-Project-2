﻿import datetime
from common import SETS, hour_bounds, pg_conn, neo_driver, norm

PG, NEO = {}, {}

PG["Q1"] = """SELECT COUNT(*), COALESCE(SUM(amount_rwf), 0)
FROM transfers WHERE sender_id = %(account)s
  AND occurred_at >= %(start)s AND occurred_at < %(end)s"""
NEO["Q1"] = """MATCH (a:Account {account_id: $account})-[t:TRANSFER]->()
WHERE t.occurred_at >= $start AND t.occurred_at < $end
RETURN count(t) AS n, coalesce(sum(t.amount_rwf), 0) AS total"""

PG["Q2"] = """SELECT (to_timestamp(occurred_at) AT TIME ZONE 'Africa/Kigali')::date AS day,
       COUNT(*) AS transfers, SUM(amount_rwf::bigint) AS total_rwf
FROM transfers GROUP BY 1 ORDER BY 1"""
NEO["Q2"] = """MATCH ()-[t:TRANSFER]->()
WITH date(datetime({epochSeconds: t.occurred_at, timezone: 'Africa/Kigali'})) AS d, t
RETURN toString(d) AS day, count(t) AS transfers, sum(t.amount_rwf) AS total_rwf
ORDER BY day"""

PG["Q3"] = """SELECT o.account_id AS other_account_id, a.device_id, d.access_type,
       GREATEST(a.first_day, o.first_day) AS overlap_start,
       LEAST(a.last_day, o.last_day) AS overlap_end
FROM account_devices a
JOIN account_devices o ON o.device_id = a.device_id AND o.account_id <> a.account_id
JOIN devices d ON d.device_id = a.device_id
WHERE a.account_id = %(account)s
  AND GREATEST(a.first_day, o.first_day) <= LEAST(a.last_day, o.last_day)
ORDER BY o.account_id, a.device_id"""
NEO["Q3"] = """MATCH (a:Account {account_id: $account})-[ua:USED_DEVICE]->(d:Device)<-[uo:USED_DEVICE]-(o:Account)
WHERE o.account_id <> $account
WITH o, d,
     CASE WHEN ua.first_day > uo.first_day THEN ua.first_day ELSE uo.first_day END AS s,
     CASE WHEN ua.last_day < uo.last_day THEN ua.last_day ELSE uo.last_day END AS e
WHERE s <= e
RETURN o.account_id AS other_account_id, d.device_id AS device_id, d.access_type AS access_type,
       s AS overlap_start, e AS overlap_end
ORDER BY other_account_id, device_id"""

PG["Q4"] = """WITH RECURSIVE edges(sk, si, dk, di) AS (
  SELECT 'Customer'::text, customer_id, 'Account'::text, account_id FROM accounts
  UNION ALL SELECT 'Account'::text, account_id, 'Customer'::text, customer_id FROM accounts
  UNION ALL SELECT 'Account'::text, account_id, 'Device'::text, device_id FROM account_devices
  UNION ALL SELECT 'Device'::text, device_id, 'Account'::text, account_id FROM account_devices
), walk(kind, id, depth) AS (
  SELECT 'Account'::text, %(account)s::integer, 0
  UNION
  SELECT e.dk, e.di, w.depth + 1
  FROM walk w JOIN edges e ON e.sk = w.kind AND e.si = w.id
  WHERE w.depth < %(depth)s
)
SELECT c.region, COUNT(DISTINCT w.id) AS accounts
FROM walk w
JOIN accounts ac ON ac.account_id = w.id
JOIN customers c ON c.customer_id = ac.customer_id
WHERE w.kind = 'Account' AND w.id <> %(account)s
GROUP BY c.region ORDER BY c.region"""
NEO["Q4"] = """MATCH (a:Account {account_id: $account})
MATCH (a)-[:OWNS|USED_DEVICE*1..__N__]-(b:Account)
WITH DISTINCT b
WHERE b.account_id <> $account
MATCH (c:Customer)-[:OWNS]->(b)
RETURN c.region AS region, count(*) AS accounts
ORDER BY region"""

PG["Q5"] = """SELECT t1.transfer_id, t2.transfer_id, t3.transfer_id, t3.receiver_id
FROM transfers t1
JOIN transfers t2 ON t2.sender_id = t1.receiver_id
 AND t2.occurred_at > t1.occurred_at AND t2.occurred_at <= t1.occurred_at + 600
 AND 90 * t1.amount_rwf::bigint <= 100 * t2.amount_rwf::bigint
 AND 100 * t2.amount_rwf::bigint <= 105 * t1.amount_rwf::bigint
JOIN transfers t3 ON t3.sender_id = t2.receiver_id
 AND t3.occurred_at > t2.occurred_at AND t3.occurred_at <= t2.occurred_at + 600
 AND 90 * t2.amount_rwf::bigint <= 100 * t3.amount_rwf::bigint
 AND 100 * t3.amount_rwf::bigint <= 105 * t2.amount_rwf::bigint
WHERE t1.sender_id = %(account)s
 AND t1.occurred_at >= %(start)s AND t1.occurred_at < %(end)s
 AND t1.receiver_id <> t1.sender_id
 AND t2.receiver_id NOT IN (t1.sender_id, t1.receiver_id)
 AND t3.receiver_id NOT IN (t1.sender_id, t1.receiver_id, t2.receiver_id)
ORDER BY 1, 2, 3"""
NEO["Q5"] = """MATCH (a0:Account {account_id: $account})-[t1:TRANSFER]->(a1:Account)-[t2:TRANSFER]->(a2:Account)-[t3:TRANSFER]->(a3:Account)
WHERE t1.occurred_at >= $start AND t1.occurred_at < $end
  AND t2.occurred_at > t1.occurred_at AND t2.occurred_at <= t1.occurred_at + 600
  AND t3.occurred_at > t2.occurred_at AND t3.occurred_at <= t2.occurred_at + 600
  AND 90 * t1.amount_rwf <= 100 * t2.amount_rwf AND 100 * t2.amount_rwf <= 105 * t1.amount_rwf
  AND 90 * t2.amount_rwf <= 100 * t3.amount_rwf AND 100 * t3.amount_rwf <= 105 * t2.amount_rwf
  AND a0 <> a1 AND a0 <> a2 AND a0 <> a3 AND a1 <> a2 AND a1 <> a3 AND a2 <> a3
RETURN t1.transfer_id AS id1, t2.transfer_id AS id2, t3.transfer_id AS id3, a3.account_id AS final_receiver
ORDER BY id1, id2, id3"""

PG["Q6"] = """WITH RECURSIVE walk(cur, ids, first_t, last_t, last_amt, n) AS (
  SELECT t.receiver_id, ARRAY[t.transfer_id], t.occurred_at, t.occurred_at, t.amount_rwf::bigint, 1
  FROM transfers t
  WHERE t.sender_id = %(account)s
    AND t.occurred_at >= %(start)s AND t.occurred_at < %(end)s
    AND t.receiver_id <> %(account)s
  UNION ALL
  SELECT t.receiver_id, w.ids || t.transfer_id, w.first_t, t.occurred_at, t.amount_rwf::bigint, w.n + 1
  FROM walk w JOIN transfers t ON t.sender_id = w.cur
  WHERE w.cur <> %(account)s
    AND w.n < 8
    AND t.occurred_at > w.last_t
    AND t.occurred_at < %(end)s
    AND t.occurred_at - w.first_t <= 1800
    AND 90 * w.last_amt <= 100 * t.amount_rwf::bigint
    AND 100 * t.amount_rwf::bigint <= 105 * w.last_amt
)
SELECT ids, n FROM walk WHERE cur = %(account)s AND n >= 3 ORDER BY ids"""
NEO["Q6"] = """MATCH p = (a:Account {account_id: $account})-[ts:TRANSFER*3..8]->(a)
WHERE all(r IN ts WHERE r.occurred_at >= $start AND r.occurred_at < $end)
  AND all(n IN nodes(p)[1..-1] WHERE n <> a)
  AND all(i IN range(0, size(ts) - 2) WHERE ts[i].occurred_at < ts[i + 1].occurred_at
        AND 90 * ts[i].amount_rwf <= 100 * ts[i + 1].amount_rwf
        AND 100 * ts[i + 1].amount_rwf <= 105 * ts[i].amount_rwf)
  AND ts[size(ts) - 1].occurred_at - ts[0].occurred_at <= 1800
RETURN [r IN ts | r.transfer_id] AS ids, size(ts) AS n
ORDER BY ids"""

PG["Q7"] = """WITH RECURSIVE walk(id, depth) AS (
  SELECT a.account_id, 0 FROM accounts a
  WHERE a.account_id = %(account)s AND a.role = 'person'
  UNION
  SELECT t.receiver_id, w.depth + 1
  FROM walk w
  JOIN transfers t ON t.sender_id = w.id
  JOIN accounts r ON r.account_id = t.receiver_id AND r.role = 'person'
  WHERE w.depth < %(bound)s
)
SELECT MIN(depth) FROM walk WHERE id = %(dest)s AND depth > 0"""
NEO["Q7"] = """MATCH (a:Account {account_id: $account, role: 'person'}), (b:Account {account_id: $dest, role: 'person'})
MATCH p = SHORTEST 1 (a)(()-[:TRANSFER]->(:Account {role: 'person'})){1,__N__}(b)
RETURN length(p) AS len"""

def canon_val(v):
    if isinstance(v, (list, tuple)):
        return tuple(canon_val(x) for x in v)
    if isinstance(v, datetime.date):
        return v.isoformat()
    return norm(v)

def canon(rows):
    out = [tuple(canon_val(v) for v in r) for r in rows]
    return sorted(out, key=lambda r: [str(x) for x in r])

def run_pg_case(q, p):
    with pg_conn().cursor() as cur:
        cur.execute("SET statement_timeout = 170000")
        cur.execute(PG[q], p)
        return canon(cur.fetchall())

def run_neo_case(q, p):
    text = NEO[q]
    if "__N__" in text:
        text = text.replace("__N__", str(int(p.get("depth") or p.get("bound"))))
    with neo_driver().session(database="neo4j") as s:
        rows = canon([r.values() for r in s.run(text, p, timeout=170)])
    if q == "Q7" and not rows:
        rows = [(None,)]
    return rows

def all_cases():
    cs = []
    for n, s in SETS.items():
        st, en = hour_bounds(s["day"])
        cs.append(("Q1", n, dict(account=s["account"], start=st, end=en)))
    cs.append(("Q2", "month", {}))
    for n, s in SETS.items():
        cs.append(("Q3", n, dict(account=s["account"])))
    for d in (4, 6, 8, 10):
        for n, s in SETS.items():
            cs.append(("Q4", f"{n}-d{d}", dict(account=s["account"], depth=d)))
    for q in ("Q5", "Q6"):
        for n, s in SETS.items():
            st, en = hour_bounds(s["day"])
            cs.append((q, n, dict(account=s["account"], start=st, end=en)))
    for b in (4, 6):
        for n, s in SETS.items():
            cs.append(("Q7", f"{n}-b{b}", dict(account=s["account"], dest=s["dest"], bound=b)))
    return cs

PG["Q7_v2"] = """WITH RECURSIVE fwd(id, depth) AS (
  SELECT a.account_id, 0 FROM accounts a
  WHERE a.account_id = %(account)s AND a.role = 'person'
  UNION
  SELECT t.receiver_id, f.depth + 1
  FROM fwd f
  JOIN transfers t ON t.sender_id = f.id
  JOIN accounts r ON r.account_id = t.receiver_id AND r.role = 'person'
  WHERE f.depth < (%(bound)s::integer + 1) / 2
), bwd(id, depth) AS (
  SELECT a.account_id, 0 FROM accounts a
  WHERE a.account_id = %(dest)s AND a.role = 'person'
  UNION
  SELECT t.sender_id, b.depth + 1
  FROM bwd b
  JOIN transfers t ON t.receiver_id = b.id
  JOIN accounts s ON s.account_id = t.sender_id AND s.role = 'person'
  WHERE b.depth < %(bound)s::integer / 2
)
SELECT MIN(f.depth + b.depth) FROM fwd f JOIN bwd b ON b.id = f.id
WHERE f.depth + b.depth > 0"""
