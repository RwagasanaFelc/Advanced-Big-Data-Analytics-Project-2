﻿import json, time
from datetime import datetime
from common import SETS, CAT, hour_bounds, run_pg, run_neo

SQL = """SELECT t1.transfer_id, t2.transfer_id, t3.transfer_id, t3.receiver_id
FROM transfers t1
JOIN transfers t2 ON t2.sender_id = t1.receiver_id
 AND t2.occurred_at > t1.occurred_at AND t2.occurred_at <= t1.occurred_at + 600
 AND 90 * t1.amount_rwf::bigint <= 100 * t2.amount_rwf::bigint
 AND 100 * t2.amount_rwf::bigint <= 105 * t1.amount_rwf::bigint
JOIN transfers t3 ON t3.sender_id = t2.receiver_id
 AND t3.occurred_at > t2.occurred_at AND t3.occurred_at <= t2.occurred_at + 600
 AND 90 * t2.amount_rwf::bigint <= 100 * t3.amount_rwf::bigint
 AND 100 * t3.amount_rwf::bigint <= 105 * t2.amount_rwf::bigint
WHERE t1.sender_id = %(account)s
 AND t1.occurred_at >= %(start)s AND t1.occurred_at < %(end)s
 AND t1.receiver_id <> t1.sender_id
 AND t2.receiver_id NOT IN (t1.sender_id, t1.receiver_id)
 AND t3.receiver_id NOT IN (t1.sender_id, t1.receiver_id, t2.receiver_id)
ORDER BY 1, 2, 3"""

CYPHER = """MATCH (a0:Account {account_id: $account})-[t1:TRANSFER]->(a1:Account)-[t2:TRANSFER]->(a2:Account)-[t3:TRANSFER]->(a3:Account)
WHERE t1.occurred_at >= $start AND t1.occurred_at < $end
  AND t2.occurred_at > t1.occurred_at AND t2.occurred_at <= t1.occurred_at + 600
  AND t3.occurred_at > t2.occurred_at AND t3.occurred_at <= t2.occurred_at + 600
  AND 90 * t1.amount_rwf <= 100 * t2.amount_rwf AND 100 * t2.amount_rwf <= 105 * t1.amount_rwf
  AND 90 * t2.amount_rwf <= 100 * t3.amount_rwf AND 100 * t3.amount_rwf <= 105 * t2.amount_rwf
  AND a0 <> a1 AND a0 <> a2 AND a0 <> a3 AND a1 <> a2 AND a1 <> a3 AND a2 <> a3
RETURN t1.transfer_id AS id1, t2.transfer_id AS id2, t3.transfer_id AS id3, a3.account_id AS final_receiver
ORDER BY id1, id2, id3"""

res = {}
first = None
print("Q5 rapid onward payments: 3 transfers through 4 distinct accounts (gaps 1-600 s, amounts 90%-105%)")
print("Set Account | SQL chains  Neo chains | match | SQL s  Neo s")
for name, s in SETS.items():
    start, end = hour_bounds(s["day"])
    p = dict(account=s["account"], start=start, end=end)
    t0 = time.perf_counter(); a = run_pg(SQL, p); t1 = time.perf_counter()
    b = run_neo(CYPHER, p); t2 = time.perf_counter()
    res[name] = dict(account=s["account"], sql=a, neo=b)
    print(f"{name:<3} {s['account']:>7} | {len(a):>10} {len(b):>11} | {a == b} | {t1-t0:5.1f} {t2-t1:6.1f}")
    if first is None and a:
        first = (name, s["account"], a[0])
json.dump(res, open("results/q5_results.json", "w"), indent=1)

print()
for name, r in res.items():
    for row in r["sql"][:3]:
        print(f"set {name} chain (transfer ids, final receiver): {row}")

if first:
    name, acct, row = first
    rows = run_pg("SELECT transfer_id, sender_id, receiver_id, occurred_at, amount_rwf FROM transfers WHERE transfer_id = ANY(%(ids)s) ORDER BY occurred_at", dict(ids=[row[0], row[1], row[2]]))
    print()
    print(f"Example chain, set {name}, review account {acct}:")
    prev = None
    for r in rows:
        when = datetime.fromtimestamp(r[3], CAT).strftime("%Y-%m-%d %H:%M:%S")
        extra = "" if prev is None else f" | +{r[3]-prev[3]} s, {100*r[4]/prev[4]:.2f}% of previous"
        print(f"  transfer {r[0]}: {r[1]} -> {r[2]} at {when} CAT, {r[4]:,} RWF{extra}")
        prev = r
