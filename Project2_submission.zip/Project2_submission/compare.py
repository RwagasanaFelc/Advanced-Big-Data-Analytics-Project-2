﻿import csv, json, time
from collections import Counter
from datetime import datetime
from common import SETS, CAT, hour_bounds, run_pg, run_neo
import cases as C

full, status = {}, []
print("61-case comparison: PostgreSQL vs Neo4j (integers normalised, rows sorted, exact comparison)", flush=True)
for i, (q, label, p) in enumerate(C.all_cases(), 1):
    out = {}
    for eng, fn in (("pg", C.run_pg_case), ("neo", C.run_neo_case)):
        t0 = time.perf_counter()
        try:
            out[eng] = (fn(q, p), "ok", time.perf_counter() - t0)
        except Exception as e:
            out[eng] = (None, "error: " + type(e).__name__, time.perf_counter() - t0)
    a, sa, ta = out["pg"]
    b, sb, tb = out["neo"]
    ok = sa == "ok" and sb == "ok" and a == b
    full[f"{q}-{label}"] = dict(q=q, label=label, params=p, sql=a, neo=b, sql_status=sa, neo_status=sb,
                                sql_sec=round(ta, 2), neo_sec=round(tb, 2), match=ok)
    na = len(a) if a is not None else sa
    nb = len(b) if b is not None else sb
    status.append((i, q, label, na, nb, ok))
    print(f"{i:>2} {q} {label:<7} SQL {str(na):>5} rows | Neo {str(nb):>5} rows | {'MATCH' if ok else 'MISMATCH'}", flush=True)

per, tot = Counter(), Counter()
for r in full.values():
    tot[r["q"]] += 1
    per[r["q"]] += r["match"]
print()
print("Per question (expected cases 6, 1, 6, 24, 6, 6, 12):")
print("  ".join(f"{q}: {per[q]}/{tot[q]}" for q in ("Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7")))
print(f"TOTAL: {sum(per.values())}/{sum(tot.values())} cases match (expected 61)")

# Q7 supporting paths are checked separately from the lengths
PATHQ = """MATCH (a:Account {account_id: $account, role: 'person'}), (b:Account {account_id: $dest, role: 'person'})
MATCH p = SHORTEST 1 (a)(()-[:TRANSFER]->(:Account {role: 'person'})){1,6}(b)
RETURN [n IN nodes(p) | n.account_id] AS accounts, [r IN relationships(p) | r.transfer_id] AS tids, length(p) AS len"""
good = 0
for name, s in SETS.items():
    rows = run_neo(PATHQ, dict(account=s["account"], dest=s["dest"]))
    if not rows:
        continue
    accounts, tids, ln = rows[0]
    roles = run_pg("SELECT account_id, role FROM accounts WHERE account_id = ANY(%(i)s)", dict(i=accounts))
    hops = {r[0]: r for r in run_pg("SELECT transfer_id, sender_id, receiver_id FROM transfers WHERE transfer_id = ANY(%(i)s)", dict(i=tids))}
    ok = (accounts[0] == s["account"] and accounts[-1] == s["dest"]
          and len(roles) == len(set(accounts)) and all(r[1] == "person" for r in roles)
          and all(t in hops and hops[t][1] == accounts[i] and hops[t][2] == accounts[i + 1] for i, t in enumerate(tids))
          and ln == len(tids) == full[f"Q7-{name}-b6"]["sql"][0][0])
    good += ok
print(f"Q7 supporting paths valid (IDs, direction, roles, events, length): {good}/6")

# Independent checks against the captured CSV rows, using plain Python
print()
print("Independent checks from data/*.csv (plain Python, no database)", flush=True)
dev_type = {}
with open("data/devices.csv", newline="") as f:
    r = csv.reader(f); next(r)
    for row in r:
        dev_type[int(row[0])] = row[1]
by_acc, by_dev = {}, {}
with open("data/account_devices.csv", newline="") as f:
    r = csv.reader(f); next(r)
    for a, d, fd, ld, _ in r:
        a, d, fd, ld = int(a), int(d), int(fd), int(ld)
        by_acc.setdefault(a, []).append((d, fd, ld))
        by_dev.setdefault(d, []).append((a, fd, ld))
ok_dev = 0
for name, s in SETS.items():
    acct = s["account"]
    rows = set()
    for d, fd, ld in by_acc.get(acct, []):
        for o, fo, lo in by_dev[d]:
            if o != acct and max(fd, fo) <= min(ld, lo):
                rows.add((o, d, dev_type[d], max(fd, fo), min(ld, lo)))
    ok_dev += C.canon(list(rows)) == full[f"Q3-{name}"]["sql"]
print(f"Device overlaps recomputed from account_devices.csv equal the SQL result: {ok_dev}/6")

wins = {}
for name, s in SETS.items():
    st, en = hour_bounds(s["day"])
    wins[(st, en + 1200)] = []
gmin = min(w[0] for w in wins)
gmax = max(w[1] for w in wins)
t0 = time.perf_counter()
with open("data/transfers.csv", newline="") as f:
    r = csv.reader(f); next(r)
    for row in r:
        ts = int(row[3])
        if ts < gmin or ts > gmax:
            continue
        for (lo, hi), lst in wins.items():
            if lo <= ts <= hi:
                lst.append((int(row[0]), int(row[1]), int(row[2]), ts, int(row[4])))
print(f"Scanned data/transfers.csv in {time.perf_counter() - t0:.0f}s", flush=True)

def build_index(rows):
    idx = {}
    for t in rows:
        idx.setdefault(t[1], []).append(t)
    return idx

def chains(idx, account, start, end):
    out = []
    for tid1, _, r1, ts1, a1 in idx.get(account, []):
        if not (start <= ts1 < end) or r1 == account:
            continue
        for tid2, _, r2, ts2, a2 in idx.get(r1, []):
            if not (ts1 < ts2 <= ts1 + 600) or r2 in (account, r1) or not (90 * a1 <= 100 * a2 <= 105 * a1):
                continue
            for tid3, _, r3, ts3, a3 in idx.get(r2, []):
                if not (ts2 < ts3 <= ts2 + 600) or r3 in (account, r1, r2) or not (90 * a2 <= 100 * a3 <= 105 * a2):
                    continue
                out.append((tid1, tid2, tid3, r3))
    return out

def cycles(idx, account, start, end):
    out = []
    def dfs(cur, ids, first_t, last_t, last_a, n):
        if cur == account:
            if n >= 3:
                out.append((tuple(ids), n))
            return
        if n >= 8:
            return
        for tid, _, r, ts, a in idx.get(cur, []):
            if last_t < ts < end and ts - first_t <= 1800 and 90 * last_a <= 100 * a <= 105 * last_a:
                dfs(r, ids + [tid], first_t, ts, a, n + 1)
    for tid, _, r, ts, a in idx.get(account, []):
        if start <= ts < end and r != account:
            dfs(r, [tid], ts, ts, a, 1)
    return out

ok_ch = ok_cy = 0
example = None
for name, s in SETS.items():
    st, en = hour_bounds(s["day"])
    idx = build_index(wins[(st, en + 1200)])
    ch = chains(idx, s["account"], st, en)
    cy = cycles(idx, s["account"], st, en)
    ok_ch += C.canon(ch) == full[f"Q5-{name}"]["sql"]
    ok_cy += C.canon(cy) == full[f"Q6-{name}"]["sql"]
    if example is None and cy:
        example = (name, s["account"], cy[0])
print(f"Q5 chains recomputed from transfers.csv equal the SQL result: {ok_ch}/6")
print(f"Q6 cycles recomputed from transfers.csv equal the SQL result: {ok_cy}/6")
if example:
    name, acct, (ids, n) = example
    print(f"Example cycle found independently: set {name}, review account {acct}, {n} transfers, ids {list(ids)}")

with open("results/compare_status.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["case_no", "question", "label", "sql_rows", "neo_rows", "match"])
    w.writerows(status)
json.dump(full, open("results/compare_full.json", "w"), indent=1)
print("saved results/compare_status.csv and results/compare_full.json")
