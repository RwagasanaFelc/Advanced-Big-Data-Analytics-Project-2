﻿import json
from datetime import datetime
from common import SETS, CAT, run_pg, run_neo

d = json.load(open("results/q7_results.json"))
print("Q7 all length comparisons (None = no route within the bound)")
print("Set Account  Dest    Bound | SQL len | Neo len | match")
for k in sorted(d, key=lambda k: (d[k]["bound"], d[k]["set"])):
    r = d[k]
    print(f"{r['set']:<3} {r['account']:>7} {r['dest']:>7} {r['bound']:>5} | {str(r['sql']):>7} | {str(r['neo']):>7} | {r['match']}")
print(f"comparisons: {len(d)} | matching: {sum(1 for r in d.values() if r['match'])}")

CYPHER = """MATCH (a:Account {account_id: $account, role: 'person'}), (b:Account {account_id: $dest, role: 'person'})
MATCH p = SHORTEST 1 (a)(()-[:TRANSFER]->(:Account {role: 'person'})){1,6}(b)
RETURN [n IN nodes(p) | n.account_id] AS accounts, [r IN relationships(p) | r.transfer_id] AS tids, length(p) AS len"""

print()
print("Path checks: one shortest path per set (bound 6), verified against PostgreSQL rows")
allok = True
for name, s in SETS.items():
    rows = run_neo(CYPHER, dict(account=s["account"], dest=s["dest"]))
    if not rows:
        print(f"{name}: no path returned"); allok = False; continue
    accounts, tids, ln = rows[0]
    roles = run_pg("SELECT account_id, role FROM accounts WHERE account_id = ANY(%(i)s)", dict(i=accounts))
    hops = {r[0]: r for r in run_pg("SELECT transfer_id, sender_id, receiver_id, occurred_at, amount_rwf FROM transfers WHERE transfer_id = ANY(%(i)s)", dict(i=tids))}
    ids_ok = accounts[0] == s["account"] and accounts[-1] == s["dest"]
    roles_ok = len(roles) == len(set(accounts)) and all(r[1] == "person" for r in roles)
    dir_ok = all(t in hops and hops[t][1] == accounts[i] and hops[t][2] == accounts[i + 1] for i, t in enumerate(tids))
    len_ok = ln == len(tids) == len(accounts) - 1 == d[f"{name}-6"]["sql"]
    ok = ids_ok and roles_ok and dir_ok and len_ok
    allok = allok and ok
    print(f"{name}: " + " -> ".join(map(str, accounts)) + f" | length {ln}")
    print(f"   ids {ids_ok} | roles all person {roles_ok} | direction+event exist {dir_ok} | length {len_ok} | PATH OK {ok}")
    for i, t in enumerate(tids):
        h = hops[t]
        when = datetime.fromtimestamp(h[3], CAT).strftime("%d Sep %H:%M:%S")
        print(f"   transfer {t}: {h[1]} -> {h[2]} at {when} CAT, {h[4]:,} RWF")
print()
print("ALL PATH CHECKS PASS:", allok)
