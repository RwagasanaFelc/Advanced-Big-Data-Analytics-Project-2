﻿import csv, time
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import run_pg, run_neo

SQL = """SELECT (to_timestamp(occurred_at) AT TIME ZONE 'Africa/Kigali')::date AS day,
       COUNT(*) AS transfers, SUM(amount_rwf::bigint) AS total_rwf
FROM transfers GROUP BY 1 ORDER BY 1"""

CYPHER = """MATCH ()-[t:TRANSFER]->()
WITH date(datetime({epochSeconds: t.occurred_at, timezone: 'Africa/Kigali'})) AS d, t
RETURN toString(d) AS day, count(t) AS transfers, sum(t.amount_rwf) AS total_rwf
ORDER BY day"""

t0 = time.perf_counter()
pg = [(str(r[0]), r[1], r[2]) for r in run_pg(SQL)]
t1 = time.perf_counter()
neo = run_neo(CYPHER)
t2 = time.perf_counter()

print("Q2 daily transfers by CAT day (Africa/Kigali)")
print("day        |  SQL count       SQL RWF |  Neo count       Neo RWF | match")
neo_map = {r[0]: r for r in neo}
for r in pg:
    n = neo_map.get(r[0], (r[0], 0, 0))
    print(f"{r[0]} | {r[1]:>10,} {r[2]:>13,} | {n[1]:>10,} {n[2]:>13,} | {r == n}")

tot_n = sum(r[1] for r in pg)
tot_v = sum(r[2] for r in pg)
print()
print("days returned: SQL", len(pg), "| Neo4j", len(neo), "| expected 30")
print("SQL sums  :", f"{tot_n:,} transfers", f"{tot_v:,} RWF")
print("Neo4j sums:", f"{sum(r[1] for r in neo):,} transfers", f"{sum(r[2] for r in neo):,} RWF")
print("capture audit: 20,003,300 transfers, 231,482,327,870 RWF")
print("ALL CHECKS PASS:", pg == neo and len(pg) == 30 and tot_n == 20003300 and tot_v == 231482327870)
print(f"seconds: PostgreSQL {t1-t0:.1f}, Neo4j {t2-t1:.1f}")

with open("results/q2_daily.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["day", "transfers", "total_rwf"])
    w.writerows(pg)

days = [r[0][5:] for r in pg]
fig, ax = plt.subplots(2, 1, figsize=(11, 7), sharex=True)
ax[0].bar(days, [r[1] / 1000 for r in pg], color="#2a6f97")
ax[0].set_ylabel("Transfers per day (thousands)")
ax[0].set_title("Q2 Daily mobile money activity, September 2026 (CAT)")
ax[1].bar(days, [r[2] / 1e6 for r in pg], color="#c8553d")
ax[1].set_ylabel("Total value per day (million RWF)")
ax[1].set_xlabel("Day in September 2026 (MM-DD, CAT)")
plt.setp(ax[1].get_xticklabels(), rotation=60, ha="right")
fig.tight_layout()
fig.savefig("results/q2_chart.png", dpi=120)
print("saved results/q2_daily.csv and results/q2_chart.png")
