\echo === ROW COUNTS ===
SELECT 'customers' t, count(*) FROM customers
UNION ALL SELECT 'accounts', count(*) FROM accounts
UNION ALL SELECT 'devices', count(*) FROM devices
UNION ALL SELECT 'account_devices', count(*) FROM account_devices
UNION ALL SELECT 'transfers', count(*) FROM transfers;

\echo === ROLES ===
SELECT role, count(*) FROM accounts GROUP BY role ORDER BY role;

\echo === TRANSFER AUDIT ===
SELECT count(*) AS n, min(occurred_at) AS earliest, max(occurred_at) AS latest,
       sum(amount_rwf::bigint) AS total_rwf FROM transfers;

\echo === CONSTRAINTS ===
SELECT conrelid::regclass AS tbl, conname, contype, convalidated
FROM pg_constraint WHERE connamespace = 'public'::regnamespace AND contype IN ('p','f','c')
ORDER BY 1, 3, 2;

\echo === INDEXES ===
SELECT tablename, indexname, indexdef FROM pg_indexes WHERE schemaname = 'public' ORDER BY 1, 2;

\echo === SIZES (1 GB = 1,000,000,000 bytes) ===
SELECT pg_database_size('mobilemoney')/1e9 AS database_gb,
       pg_table_size('transfers')/1e9      AS transfers_table_gb,
       pg_indexes_size('transfers')/1e9    AS transfers_indexes_gb,
       (pg_total_relation_size('accounts') + pg_total_relation_size('account_devices'))/1e9 AS other_gb;
